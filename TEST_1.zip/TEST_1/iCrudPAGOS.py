from iCrud import ICrud
from datetime import date
from utilities import borrarPantalla,gotoxy, red_color,reset_color,blue_color, yellow_color,cyan_color
from clsJson import JsonFile
from pago import Pago
import time
import os

path, file = os.path.split(__file__)

class CrudPago(ICrud):
    json_file = JsonFile(f"{path}/archivos/Pago.json")   

    def create(self):
        # Cargar los datos necesarios
        asignaturas = JsonFile(f"{path}/archivos/Asignaturas.json").read()
        estudiantes = JsonFile(f"{path}/archivos/Estudiantes.json").read()

        # Agregar pago a estudiante en base de datos
        borrarPantalla()
        gotoxy(27,2),print(red_color + "********** Registrar Pago **********" + reset_color)
        print("-"*100)
        print("Seleccione el Estudiante para agregar la asignatura:")
        for i, est in enumerate(estudiantes):
            print(f"{i + 1}. {est['Nombre']}")
        try:
            opcion_estudiante = int(input("Opción: ")) - 1
            if opcion_estudiante < 0 or opcion_estudiante >= len(estudiantes):
                raise ValueError("Opción inválida")
            estudiante_seleccionado = estudiantes[opcion_estudiante]
        except ValueError as e:
            print(e)
        borrarPantalla()   

        # Seleccionar asignatura
        borrarPantalla()
        gotoxy(27,2),print(red_color + "********** Registrar pago **********" + reset_color)
        print("-"*100)
        print("Seleccione la Asignatura:")
        for i, asign in enumerate(asignaturas):
            print(f"{i + 1}. {asign['Descripcion']}")
        while True:
            try:
                opcion_asignatura = int(input("Opción: ")) - 1
                if opcion_asignatura < 0 or opcion_asignatura >= len(asignaturas):
                    raise ValueError("Opción inválida")
                asignatura_seleccionada = asignaturas[opcion_asignatura]
                break
            except ValueError as e:
                print(e)

               # Crear una nueva instancia de Nota
        nueva_pago = Pago(id=len(self.json_file.read()) + 1, 
                        fecha_pago=date.today().strftime('%Y-%m-%d'), 
                        estudiante=estudiante_seleccionado['Nombre'])

        while True:
            borrarPantalla()
            gotoxy(27,2),print(red_color + "********** Registrar pago **********" + reset_color)
            print("-"*100)
            gotoxy(1, 4), print(f"{yellow_color}Fecha:{blue_color}{nueva_pago.fecha_pago}")
            gotoxy(45, 4), print(f"{yellow_color}Id:{blue_color}{nueva_pago.id} ")
            gotoxy(1, 5), print(f"{yellow_color}Estudiante:{blue_color}{nueva_pago.estudiante} ")
            gotoxy(1, 6), print(f"{yellow_color}Asignatura: {blue_color}{asignatura_seleccionada['Descripcion']} ")
            print("-"*100)
            # Ingresar notas para el estudiante

            gotoxy(27, 8)
            print(f"{yellow_color}Detalle de Pago")
            print("-"*100)
            gotoxy(1, 10), print(f"{yellow_color}Estudiante")
            gotoxy(15, 10), print(f"{yellow_color}Precio")
            gotoxy(35, 10), print(f"{yellow_color}Total")


            gotoxy(1,11);print(f"{blue_color}{estudiante_seleccionado["Nombre"]}")
            gotoxy(21,11);pago = float(input())
            total = 0
            total += pago
            gotoxy(42,11);print(f"{blue_color}{total}")
  

            # Agregar la nota para el estudiante
            nueva_pago.addPago(asignatura_seleccionada,pago)

            # Preguntar si desea agregar otra nota
            continuar = input("¿Desea terminar? (s/n): ").lower()
            if continuar == 's':
                break

        # Guardar la nueva nota en el archivo JSON
        pagos = self.json_file.read()
        pagos.append(nueva_pago.to_dict())  # Convertir la nota a diccionario
        self.json_file.save(pagos)
        print("pago creada con éxito.")
        time.sleep(2)


    def update():
        pass

    def delete(self):
        borrarPantalla()
        pagos = self.json_file.read()
        if not pagos:
            print("No hay pagos registradas para eliminar.")
            time.sleep(2)
            return

        print("Seleccione el pago a eliminar:")
        for i, pago in enumerate(pagos):
            print(f"{i + 1}. Pago ID {pago['id']} - Estudiante: {pago['estudiante']}")
        opcion = int(input("Opción: ")) - 1

        if opcion < 0 or opcion >= len(pagos):
            print("Opción inválida.")
            return

        # Confirmar eliminación
        pago_seleccionado = pagos[opcion]
        confirmacion = input(f"¿Está seguro de que desea eliminar el pago ID {pago_seleccionado['id']}? (s/n): ").lower()

        if confirmacion == 's':
            pagos.pop(opcion)
            self.json_file.save(pagos)
            print("Pago eliminada con éxito.")
        else:
            print("Eliminación cancelada.")

        time.sleep(2)
    def consult(self):
        borrarPantalla()
        pagos = self.json_file.read()
        if not pagos:
            print("No hay notas registradas.")
        else:
            print("Pagos REGISTRADOS:")
            print("=" * 50)
            for pago in pagos:
                print(f"ID Pago: {pago['id']}")
                print(f"Estudiante: {pago['estudiante']}")
                print(f"Fecha: {pago['fecha_pago']}")
                print("-" * 50)
                for detalle in pago['detallePago']:
                    print(f"Id: {detalle['id']}")
                    print(f"Asignatura: {detalle['asignatura']}")
                    print(f"Pago: {detalle['pago']}")
                    print("-" * 50)
                print("=" * 50)
        input("\nPresione Enter para continuar...")