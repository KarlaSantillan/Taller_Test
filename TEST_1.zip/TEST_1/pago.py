from datetime import date
class Pago:
    def __init__(self, id, fecha_pago, estudiante):
        self.id = id  # Identificador único para el pago.
        self.fecha_pago = fecha_pago  # fecha del pago.
        self.estudiante = estudiante  # Estudiante que realiza el pago.
        self.total_pagos=0
        self.detallePago = []  # detalles de los pagos por asignaturas.

    def __str__(self):
        return (f"Pago ID: {self.id}, Fecha Pago: {self.fecha_pago}, Estudiante: {self.estudiante}, "
                    f"Total: {self.total_pagos}")

    def addPago(self, asignatura,pago):
        nuevo_detalle = DetallePago(
            id=len(self.detallePago) + 1,
            asignatura=asignatura,
            pago=pago
        )
        self.detallePago.append(nuevo_detalle)

    def to_dict(self):
        return {
            'id': self.id,
            'fecha_pago': self.fecha_pago,
            'estudiante': self.estudiante,
            'total_pagos': self.total_pagos,
            'detallePago': [detalle.__dict__ for detalle in self.detallePago],
        }

class DetallePago:
    def __init__(self, id,asignatura,pago ):
        self.id = id  # Identificador único para el detalle del pago.
        self.asignatura = asignatura  # asignatura que se paga.
        self.pago= pago # costo de la asignatura.
